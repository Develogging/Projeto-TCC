#include <stdio.h>
#include <stdlib.h>

int main(){
    FILE *arquivo;
    arquivo = fopen("teste.txt","w");    

    return 0;
}