#include <stdio.h>
#include <stdlib.h>

int main(){
    FILE *arquivo;


    return 0;
}