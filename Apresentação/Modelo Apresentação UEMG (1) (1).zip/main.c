#include <stdio.h>
#include <stdlib.h>

int main(){
    printf("Hello World");
    return 0;
}